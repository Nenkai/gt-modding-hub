         mkpsxiso configurations for GT2 discs
=================================================================
	 by pez2k
=================================================================

Build configurations for the mkpsxiso tool to replicate / rebuild
Gran Turismo 2 retail discs.

=================================================================

How to use:

Place the mkpsxiso tool, the relevant config, all of the files
from the original disc, and the appropriate license data file
into a folder, then run the following command:
mkpsxiso <configname>.xml

The MUSIC.DAT and STREAM.DAT files MUST be extracted from the
original disc image using an XA-aware tool such as XtrActor .NET
in order to be sure that all of the data is extracted. Most ISO
tools will not extract the whole file, and the rebuilt disc will
then not function correctly.

The license data files can be obtained from the official PsyQ
SDK, and are named LICENSEx.DAT, where x is J, A or E depending
on the disc region. As far as I am aware, these cannot be
extracted from the original disc image.

=================================================================

THE END