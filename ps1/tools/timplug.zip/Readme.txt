
This directory contains plug-ins for Adobe Photoshop, versions 2.5 and 3.0.

                      
 *readme.txt   -        Overview of Abobe directory contents.
 *TIMEXPE.8BE  1.2E     Export module for the DTL-H201.  This allows you to 
		        create or edit files in Photoshop, and output the image 
		        directly to the DTL-H201 (Artist Board) for viewing on 
		        the screen.  Indexed color and RGB color files may be output.
 *TIMEXPE.PDF   -       Installation instructions for TIMEXPE.8BE in Adobe Acrobat.
 *TIMEXPE.TXT   -       Installation instructions for TIMEXPE.8BE.
 *TIMFMTE.8BI   1.2E    TIM format module.  Allows importing files with a ".TIM" file 
	                extension.  Compatible only with Adobe Photoshop 2.5
 *TIMFMTE.TXT    -      Installation instructions for TIMFMTE.8BI.
 *TIMformatE.8BI 1.3E   TIM format module.  Allows importing files with a ".TIM" file 
	                extension.  Compatible only with Adobe Photoshop 3.0


    
